package uninter.poo;

public class Euro extends Moeda { //classe filha
	
	public Euro (double valorInicio) {
		this.valor = valorInicio;
	}

	@Override
	public void info() { //metodo para exibir a informação
		System.out.println("Euro - " + valor);
		
	}

	@Override
	public double converter() { //metodo para converter as moedas
		return this.valor * 5.3; //valor do euro para ser calculado o valor final em reais
		
	}

}
