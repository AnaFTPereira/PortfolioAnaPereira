 //main
package uninter.poo;

public class Principal {

    public static void main(String[] args) { //criação de uma instância da classe menu
    	
        Menu menu = new Menu();
        menu.exibirMenu(); //é chamado para exibir o menu principal
        
    }

}
       