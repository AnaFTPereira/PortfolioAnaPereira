package uninter.poo;

public class Real extends Moeda { //classe filha
	
	public Real(double valorInicio) {
		this.valor = valorInicio;
	}

	@Override
	public void info() { //metodo para exibir a informação
		System.out.println("Real - " + valor);
		
	}

	@Override
	public double converter() { //metodo para converter as moedas
		return this.valor;
	}

	
}
