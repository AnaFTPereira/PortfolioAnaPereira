package uninter.poo;

import java.util.ArrayList;

public class Cofrinho {
	
	private ArrayList<Moeda> listaMoedas; //armazenar as moedas no cofrinho
	
	public Cofrinho() {
		this.listaMoedas = new ArrayList<>();
	}

	public void adicionar(Moeda moeda) { //adicionar uma moeda na lista
		this.listaMoedas.add(moeda);
		
	}
	
	public void remover(Moeda moeda) { //remover uma moeda na lista
		this.listaMoedas.remove(moeda);
		
	}
	
	public void listagemMoedas() { //listar todas as moedas do cofrinho
		
		if (this.listaMoedas.isEmpty()) {
			System.out.println("Nenhuma moeda no cofrinho.");
			return;
		}
		
		for (Moeda moeda : this.listaMoedas) {
			moeda.info();
		}
	}

	public double totalConvertido() { //calcula o valor total acumulado de todas as moedas do cofrinho convertendo cada valor para a moeda correspondente
		
		if (this.listaMoedas.isEmpty()) {
			return 0;
		}
		
		double valorAcumulado = 0; //acumular todo o valor
		
		for (Moeda moeda : this.listaMoedas) {
			valorAcumulado = valorAcumulado + moeda.converter();
		}
		
		return valorAcumulado; //retornar o valor total acumulado

	}
}
