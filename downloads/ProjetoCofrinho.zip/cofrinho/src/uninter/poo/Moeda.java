package uninter.poo;

public abstract class Moeda { //classe mãe

	protected double valor;
	
	public abstract void info(); //metodo 1
	public abstract double converter(); //metodo 2
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass()) //verificar se os objetos são diferentes
			return false;

		Moeda other = (Moeda) obj;
		return Double.doubleToLongBits(valor) == Double.doubleToLongBits(other.valor); //metodo para fazer comparação dos valores das moedas
	}
	
}
