package uninter.poo;

public class Dolar extends Moeda { //classe filha
	
	public Dolar (double valorInicio) {
		this.valor = valorInicio;
	}

	@Override
	public void info() { //metodo para exibir a informação
		System.out.println("Dolar - " + valor);
		
	}

	@Override
	public double converter() { //metodo para converter as moedas
		return this.valor * 4.7; //valor do dolar para ser calculado o valor final em reais
		
	}

}
