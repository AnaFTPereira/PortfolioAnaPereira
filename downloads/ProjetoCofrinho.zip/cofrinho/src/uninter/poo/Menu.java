package uninter.poo;

import java.util.Scanner;

public class Menu {
	
	private Scanner scanner;
	private Cofrinho cofrinho;
	
	public Menu() {
		scanner = new Scanner(System.in);
		cofrinho = new Cofrinho();
		
	}
	
	public void exibirMenu() { //metodo de entrada com as opções do menu
		System.out.println("MENU COFRINHO DA ANA FLAVIA TEIXEIRA PEREIRA RU 4378947"); //identificador pessoal
        System.out.println("1-Adicionar moedas");
        System.out.println("2-Remover moedas");
        System.out.println("3-Listar moedas");
        System.out.println("4-Calcular total em reais");
        System.out.println("0-Sair");
        
        String opcao = scanner.next();
        
        switch (opcao) {
        	case "0":
        		System.out.println("Cofrinho encerrado.");
        		break;
        		
        	case "1":
        		subMenu(); //metodo chmado quando seleciona adicionar moedas
        		exibirMenu();
        		break;
        		
        	case "2":
        		menuRemove(); //metodo chamado quando seleciona remover moedas
        		exibirMenu();
        		break;
        		
        	case "3":
        		cofrinho.listagemMoedas();
        		exibirMenu();
        		break;
        		
        	case "4":
        		double valorConvertido = cofrinho.totalConvertido(); //metodo para calcular o valor total adicionado no cofrinho em reais
        		String valorTotalTexto = String.format("%.2f", valorConvertido); //formatar o valor em reais com duas casas decimais
        		valorTotalTexto = valorTotalTexto.replace(".", ","); //metodo para trocar o ponto pela virgula nos valores
        		System.out.println("O valor total convertido é: " + valorTotalTexto);
        		exibirMenu();
        		break;
        		
        	default:
        		System.out.println("Opção Inválida.");
        		exibirMenu();
        		break;
    	
        }
	}
	
	private void subMenu() { //metodo chmado quando seleciona adicionar moedas
		System.out.println("Escolha a moeda:");
		System.out.println("1-Real");
		System.out.println("2-Dolar");
		System.out.println("3-Euro");
		
		int escolhaMoeda = scanner.nextInt();
		
		System.out.println("Digite o valor:");
		String valorMoedaTexto = scanner.next();
		
		valorMoedaTexto = valorMoedaTexto.replace(",", "."); //metodo para trocar a virgula pelo ponto nos valores
		double valorMoeda = Double.valueOf(valorMoedaTexto);
		
		Moeda moeda = null;
		
		if (escolhaMoeda == 1) {
			moeda = new Real(valorMoeda);
		} else if (escolhaMoeda == 2) {
			moeda = new Dolar(valorMoeda);
		} else if (escolhaMoeda == 3 ) {
			moeda = new Euro (valorMoeda);
   		} else {
   			System.out.println("Moeda inválida.");
   			exibirMenu();
   		}
		
		cofrinho.adicionar(moeda);
		System.out.println("Moeda adicionada com sucesso!"); //mensagem quando a moeda é adicionada
	}
	
	private void menuRemove() { //metodo chamado quando seleciona remover moedas
		System.out.println("Escolha a moeda que deseja remover:");
		System.out.println("1-Real");
		System.out.println("2-Dolar");
		System.out.println("3-Euro");
		
		int escolhaMoeda = scanner.nextInt();
		
		System.out.println("Digite o valor para ser removido:");
		String valorMoedaTexto = scanner.next();
		
		valorMoedaTexto = valorMoedaTexto.replace(",", "."); //metodo para trocar a virgula pelo ponto nos valores
		double valorMoeda = Double.valueOf(valorMoedaTexto);
		
		Moeda moeda = null;
		
		if (escolhaMoeda == 1) {
			moeda = new Real(valorMoeda);
		} else if (escolhaMoeda == 2) {
			moeda = new Dolar(valorMoeda);
		} else if (escolhaMoeda == 3 ) {
			moeda = new Euro (valorMoeda);
   		} else {
   			System.out.println("Moeda inválida.");
   			exibirMenu();
   		}
		
		cofrinho.remover(moeda);
		System.out.println("Moeda removida com sucesso!"); //mensagem quando a moeda é removida
	}

}
